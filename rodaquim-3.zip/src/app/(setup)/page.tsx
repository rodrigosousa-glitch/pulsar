// @polsia:user-owned — configure the home page in src/lib/business/landing/config.ts.
import type { Metadata } from 'next';
import { LandingPage } from '@/components/custom/landing/landing-page';
import { siteDescription, siteName } from '@/lib/brand';
import { landingConfig } from '@/lib/business/landing/config';
import { landingConfigSchema } from '@/lib/business/landing/schema';

export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  alternates: { canonical: '/' },
};

export default function HomePage() {
  return (
    <main>
      <LandingPage config={landingConfigSchema.parse(landingConfig)} />
    </main>
  );
}
