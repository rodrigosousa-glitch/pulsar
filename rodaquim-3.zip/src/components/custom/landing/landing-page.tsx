// @polsia:user-owned
'use client';

import {
  ArrowDown,
  ArrowUpRight,
  Check,
  Circle,
  Clock3,
  Globe2,
  Heart,
  Layers3,
  Leaf,
  Menu,
  MessageSquare,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { domAnimation, LazyMotion, MotionConfig, useReducedMotion } from 'motion/react';
import * as m from 'motion/react-m';
import Image from 'next/image';
import Link from 'next/link';
import { useId, useState } from 'react';
import { Button } from '@/components/ui/button';
import { landingThemeStyle } from '@/lib/business/landing/theme';
import type {
  HeroSection,
  LandingConfig,
  LandingSection,
  StepsSection,
} from '@/lib/business/landing/types';
import { LandingAction } from './landing-action';
import styles from './landing-page.module.css';
import { PracticalSection } from './practical-sections';
import { TrustSection } from './trust-sections';
import { VisualVariant } from './visual-variants';

const icons = {
  layers: Layers3,
  sparkles: Sparkles,
  clock: Clock3,
  shield: ShieldCheck,
  leaf: Leaf,
  heart: Heart,
  arrow: ArrowUpRight,
  globe: Globe2,
};

function DashboardMedia({ alt }: { alt: string }) {
  return (
    <div className={styles.dashboard} role="img" aria-label={alt}>
      <div className={styles.dashboardTop}>
        <span className={styles.dashboardBrand}>
          <Layers3 size={15} /> Workspace
        </span>
        <span className={styles.dashboardSearch}>
          <Search size={12} /> Search anything <kbd>⌘ K</kbd>
        </span>
        <span className={styles.avatar}>JL</span>
      </div>
      <div className={styles.dashboardBody}>
        <div className={styles.dashboardSidebar}>
          <span className={styles.sidebarLabel}>Your workspace</span>
          <span>
            <Circle size={12} /> Overview
          </span>
          <span className={styles.activeItem}>
            <Layers3 size={12} /> Projects <span>6</span>
          </span>
          <span>
            <MessageSquare size={12} /> Inbox <i />
          </span>
          <span>
            <Clock3 size={12} /> My tasks
          </span>
          <div className={styles.sidebarDivider} />
          <span className={styles.sidebarLabel}>Favorites</span>
          <span>
            <i className={styles.projectDot} /> Website launch
          </span>
          <span>
            <i className={styles.projectDot} /> Brand refresh
          </span>
          <div className={styles.sidebarBottom}>
            <span className={styles.avatar}>JL</span>
            <span>
              Jamie Lee<small>Personal workspace</small>
            </span>
          </div>
        </div>
        <div className={styles.dashboardMain}>
          <div className={styles.projectHeading}>
            <span>Projects / Website launch</span>
            <span>•••</span>
          </div>
          <div className={styles.projectTitle}>
            <div>
              <h3>Website launch</h3>
              <p>Great things happen when everyone’s in sync.</p>
            </div>
            <span className={styles.mockButton}>
              <Plus size={11} /> Add task
            </span>
          </div>
          <div className={styles.projectTabs}>
            <span>Board</span>
            <span>List</span>
            <span>Timeline</span>
            <span className={styles.teamAvatars}>
              <i>JL</i>
              <i>AM</i>
              <i>RK</i>
              <i>+2</i>
            </span>
          </div>
          <div className={styles.kanban}>
            <div className={styles.kanbanColumn}>
              <div className={styles.columnHeading}>
                <span>
                  <i /> Planned <small>3</small>
                </span>
                <Plus size={11} />
              </div>
              <div className={styles.task}>
                <span className={styles.taskTag}>Research</span>
                <strong>Collect customer insights</strong>
                <p>Bring the customer into every decision.</p>
                <div>
                  <span>May 24</span>
                  <i>AM</i>
                </div>
              </div>
              <div className={styles.task}>
                <span className={styles.taskTag}>Content</span>
                <strong>Write the launch story</strong>
                <div>
                  <span>
                    <MessageSquare size={10} /> 4
                  </span>
                  <i>JL</i>
                </div>
              </div>
            </div>
            <div className={styles.kanbanColumn}>
              <div className={styles.columnHeading}>
                <span>
                  <i /> In progress <small>2</small>
                </span>
                <Plus size={11} />
              </div>
              <div className={styles.task}>
                <div className={styles.taskArtwork}>
                  <span />
                  <span />
                  <span />
                </div>
                <span className={styles.taskTag}>Design</span>
                <strong>Make room for a fresh start</strong>
                <div>
                  <span>
                    <Check size={10} /> 3 / 5
                  </span>
                  <i>RK</i>
                </div>
              </div>
              <div className={styles.task}>
                <span className={styles.taskTag}>Development</span>
                <strong>Build the landing page</strong>
                <div>
                  <span>May 26</span>
                  <i>AM</i>
                </div>
              </div>
            </div>
            <div className={styles.kanbanColumn}>
              <div className={styles.columnHeading}>
                <span>
                  <i /> Complete <small>4</small>
                </span>
                <Plus size={11} />
              </div>
              <div className={styles.task}>
                <span className={styles.taskTag}>Strategy</span>
                <strong>Find our shared direction</strong>
                <p>A clear plan. A happy team.</p>
                <div>
                  <span>
                    <Check size={10} /> Done
                  </span>
                  <i>JL</i>
                </div>
              </div>
              <div className={styles.task}>
                <span className={styles.taskTag}>Design</span>
                <strong>Define the visual identity</strong>
                <div>
                  <span>
                    <Check size={10} /> Done
                  </span>
                  <i>RK</i>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.dashboardStatus}>
            <span>
              <Check size={11} /> All changes saved
            </span>
            <span>A little more clarity. A lot less busywork.</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function HeroMedia({
  media,
  priority = false,
}: {
  media: HeroSection['media'];
  priority?: boolean;
}) {
  if (media.kind === 'dashboard')
    return (
      <div className={styles.dashboardStage}>
        <DashboardMedia alt={media.alt} />
        <div className={styles.dashboardNotification}>
          <span>
            <Check size={15} />
          </span>
          <div>
            <strong>{media.caption ?? 'Everything, moving together.'}</strong>
            <small>One shared place for your team’s next big thing.</small>
          </div>
        </div>
      </div>
    );
  return (
    <figure
      className={`${styles.heroImage} ${media.kind === 'product' ? styles.productImage : ''}`}
    >
      {media.src && (
        <Image
          src={media.src}
          alt={media.alt}
          fill
          sizes="(max-width: 700px) 100vw, 65vw"
          priority={priority}
          unoptimized
        />
      )}
      {media.caption && (
        <figcaption>
          {media.caption}
          <ArrowUpRight size={16} aria-hidden="true" />
        </figcaption>
      )}
    </figure>
  );
}

function SectionHeading({ title, description }: { title: string; description?: string }) {
  return (
    <div className={styles.sectionHeading}>
      <h2>{title}</h2>
      {description && <p>{description}</p>}
    </div>
  );
}

function StepImage({ media }: { media: NonNullable<StepsSection['media']> }) {
  return (
    <div className={styles.stepImage}>
      <Image
        src={media.src}
        alt={media.alt}
        fill
        sizes="(max-width: 850px) 100vw, 45vw"
        unoptimized
      />
    </div>
  );
}

function StepsContent({ section }: { section: StepsSection }) {
  const accordionName = useId();
  return (
    <div className={styles[`steps_${section.variant}`]}>
      <SectionHeading title={section.heading} description={section.description} />
      {section.variant === 'image-accordion' ? (
        <div className={styles.stepsAccordionLayout}>
          {section.media && <StepImage media={section.media} />}
          <ol className={styles.stepAccordionItems}>
            {section.items.map((item, index) => (
              <li key={item.title}>
                <details className={styles.stepDisclosure} name={accordionName} open={index === 0}>
                  <summary>
                    <span className={styles.stepNumber}>{String(index + 1).padStart(2, '0')}</span>
                    <span className={styles.stepTitle}>{item.title}</span>
                    <Plus size={18} aria-hidden="true" />
                  </summary>
                  <p>{item.description}</p>
                </details>
              </li>
            ))}
          </ol>
        </div>
      ) : (
        <ol className={styles.stepItems}>
          {section.items.map((item, index) => (
            <li key={item.title}>
              {section.variant === 'alternating' && item.media && <StepImage media={item.media} />}
              <div className={styles.stepCopy}>
                <span className={styles.stepNumber}>{String(index + 1).padStart(2, '0')}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function SectionContent({ section }: { section: LandingSection }) {
  switch (section.type) {
    case 'hero':
      if (section.variant === 'immersive' || section.variant === 'collage')
        return <VisualVariant section={section} />;
      return (
        <div className={`${styles.hero} ${styles[`hero_${section.variant}`]}`}>
          <div className={styles.heroCopy}>
            {section.eyebrow && (
              <p className={styles.eyebrow}>
                <span />
                {section.eyebrow}
              </p>
            )}
            <h1>{section.title}</h1>
            <p className={styles.heroDescription}>{section.description}</p>
            <div className={styles.actions}>
              <LandingAction action={section.primaryAction} />
              {section.secondaryAction && (
                <LandingAction action={section.secondaryAction} secondary />
              )}
            </div>
            {section.note && (
              <p className={styles.heroNote}>
                <Check size={13} aria-hidden="true" />
                {section.note}
              </p>
            )}
          </div>
          <HeroMedia media={section.media} priority />
        </div>
      );
    case 'features':
      if (section.variant === 'bento' || section.variant === 'tabs')
        return <VisualVariant section={section} />;
      return (
        <div className={`${styles.features} ${styles[`features_${section.variant}`]}`}>
          <SectionHeading title={section.heading} description={section.description} />
          <div className={styles.featureItems}>
            {section.items.map((item) => {
              const Icon = icons[item.icon];
              return (
                <article className={styles.feature} key={item.title}>
                  <span className={styles.featureIcon}>
                    <Icon size={22} strokeWidth={1.5} />
                  </span>
                  <div>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      );
    case 'gallery':
      if (section.variant === 'catalog' || section.variant === 'menu')
        return <VisualVariant section={section} />;
      return (
        <div className={`${styles.gallery} ${styles[`gallery_${section.variant}`]}`}>
          <SectionHeading title={section.heading} description={section.description} />
          <div className={styles.galleryItems}>
            {section.items.map((item) => (
              <article className={styles.galleryCard} key={item.title}>
                <div className={styles.galleryImage}>
                  {item.image && (
                    <Image
                      src={item.image}
                      alt={item.alt ?? item.title}
                      fill
                      sizes="(max-width: 650px) 100vw, 40vw"
                      unoptimized
                    />
                  )}
                  {item.tag && <span className={styles.galleryTag}>{item.tag}</span>}
                </div>
                <div className={styles.galleryCaption}>
                  <div>
                    <h3>{item.title}</h3>
                    {item.subtitle && <p>{item.subtitle}</p>}
                  </div>
                  {item.action && <LandingAction action={item.action} secondary compact />}
                </div>
              </article>
            ))}
          </div>
        </div>
      );
    case 'steps':
      return <StepsContent section={section} />;
    case 'pricing':
      return (
        <div className={`${styles.pricing} ${styles[`pricing_${section.variant}`]}`}>
          <SectionHeading title={section.heading} description={section.description} />
          <div className={styles.pricingItems}>
            {section.plans.map((plan) => (
              <article
                className={`${styles.priceCard} ${plan.featured ? styles.featuredPlan : ''}`}
                key={plan.name}
              >
                <div className={styles.planHeading}>
                  <h3>{plan.name}</h3>
                  {plan.featured && <span>Our recommendation</span>}
                </div>
                <p>{plan.description}</p>
                <div className={styles.price}>
                  {plan.price}
                  {plan.period && <span>{plan.period}</span>}
                </div>
                <ul>
                  {plan.features.map((feature) => (
                    <li key={feature}>
                      <Check size={15} />
                      {feature}
                    </li>
                  ))}
                </ul>
                <LandingAction action={plan.action} secondary={!plan.featured} />
              </article>
            ))}
          </div>
        </div>
      );
    case 'testimonial':
      if (section.variant === 'wall' || section.variant === 'carousel')
        return <TrustSection section={section} />;
      return (
        <div className={`${styles.testimonial} ${styles[`testimonial_${section.variant}`]}`}>
          <span className={styles.quoteMark} aria-hidden="true">
            “
          </span>
          <blockquote>
            <p>{section.quote}</p>
            <footer>
              <span className={styles.authorAvatar}>
                {section.author
                  ?.split(' ')
                  .map((name) => name[0])
                  .slice(0, 2)
                  .join('')}
              </span>
              <div className={styles.authorDetails}>
                <cite>{section.author}</cite>
                <span>{section.role}</span>
              </div>
            </footer>
          </blockquote>
        </div>
      );
    case 'logos':
    case 'stats':
    case 'team':
      return <TrustSection section={section} />;
    case 'contact':
    case 'comparison':
    case 'agenda':
      return <PracticalSection section={section} />;
    case 'faq':
      return (
        <div className={`${styles.faq} ${styles[`faq_${section.variant}`]}`}>
          <SectionHeading title={section.heading} />
          <div className={styles.faqItems}>
            {section.items.map((item) => (
              <details
                className={styles.faqItem}
                key={item.question}
                open={section.variant === 'columns' ? true : undefined}
              >
                <summary>
                  {item.question}
                  <Plus size={18} aria-hidden="true" />
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      );
    case 'cta':
      return (
        <div className={`${styles.cta} ${styles[`cta_${section.variant}`]}`}>
          <div>
            <h2>{section.heading}</h2>
            {section.description && <p>{section.description}</p>}
          </div>
          <div className={styles.actions}>
            <LandingAction action={section.action} />
            {section.secondaryAction && (
              <LandingAction action={section.secondaryAction} secondary />
            )}
          </div>
        </div>
      );
  }
}

export function LandingPage({ config }: { config: LandingConfig }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const reduceMotion = useReducedMotion();
  const menuId = useId();
  const sections = config.sections.filter((section) => section.enabled);
  const visibleIds = new Set(sections.map((section) => section.id));
  const navigation = config.navigation.filter((item) => visibleIds.has(item.sectionId));
  return (
    <LazyMotion features={domAnimation} strict>
      <MotionConfig reducedMotion="user">
        <div
          className={styles.page}
          style={landingThemeStyle(config.theme)}
          data-palette={config.theme.palette}
          data-typography={config.theme.typography}
          data-radius={config.theme.radius}
          data-landing={config.id}
        >
          <header className={styles.header}>
            <Link
              href={sections[0] ? `#${sections[0].id}` : '#landing-footer'}
              className={styles.brand}
              aria-label={`${config.brand.name} home`}
            >
              <span className={styles.brandMark}>{config.brand.monogram}</span>
              {config.brand.name}
            </Link>
            <nav className={styles.desktopNav} aria-label={`${config.brand.name} navigation`}>
              {navigation.map((item) => (
                <Link key={item.sectionId} href={`#${item.sectionId}`}>
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className={styles.headerAction}>
              <LandingAction action={config.primaryAction} compact />
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={styles.menuToggle}
              aria-expanded={menuOpen}
              aria-controls={menuId}
              aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X /> : <Menu />}
            </Button>
            {menuOpen && (
              <m.nav
                id={menuId}
                className={styles.mobileNav}
                aria-label="Mobile navigation"
                initial={reduceMotion ? false : { opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18 }}
              >
                {navigation.map((item) => (
                  <Link
                    key={item.sectionId}
                    href={`#${item.sectionId}`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {item.label}
                    <ArrowDown size={14} />
                  </Link>
                ))}
                <LandingAction action={config.primaryAction} onClick={() => setMenuOpen(false)} />
              </m.nav>
            )}
          </header>
          <div className={styles.sections}>
            {sections.map((section) => (
              <m.section
                key={section.id}
                id={section.id}
                // Keep server-rendered content visible, even without JavaScript.
                // Keyframes start only when a section enters the viewport, once.
                initial={false}
                whileInView={reduceMotion ? undefined : { opacity: [0.7, 1], y: [12, 0] }}
                viewport={{ once: true, amount: 'some' }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                data-section-id={section.id}
                data-section-type={section.type}
                data-section-variant={section.variant}
                className={`${styles.section} ${section.type === 'hero' ? styles.heroSection : ''} ${section.type === 'testimonial' && (section.variant === 'spotlight' || section.variant === 'split') ? styles.quoteSection : ''} ${section.type === 'cta' ? styles.ctaSection : ''}`}
                aria-label={
                  section.type === 'testimonial'
                    ? 'Customer story'
                    : 'heading' in section
                      ? section.heading
                      : section.title
                }
              >
                <SectionContent section={section} />
              </m.section>
            ))}
          </div>
          <footer id="landing-footer" className={styles.footer}>
            <div className={styles.footerTop}>
              <div>
                <Link
                  href={sections[0] ? `#${sections[0].id}` : '#landing-footer'}
                  className={styles.brand}
                >
                  <span className={styles.brandMark}>{config.brand.monogram}</span>
                  {config.brand.name}
                </Link>
                <p>{config.footer.description}</p>
              </div>
              <div className={styles.footerLinks}>
                {config.footer.links
                  .filter(
                    (link) =>
                      !link.href.startsWith('#') ||
                      link.href === '#landing-footer' ||
                      visibleIds.has(link.href.slice(1)),
                  )
                  .map((link) => (
                    <Link key={`${link.label}-${link.href}`} href={link.href}>
                      {link.label}
                      <ArrowUpRight size={13} />
                    </Link>
                  ))}
              </div>
            </div>
            <div className={styles.footerBottom}>
              <span>{config.footer.copyright}</span>
              <span>{config.brand.tagline}</span>
            </div>
          </footer>
        </div>
      </MotionConfig>
    </LazyMotion>
  );
}
