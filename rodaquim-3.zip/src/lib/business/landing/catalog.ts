// @polsia:user-owned — available landing sections and layouts for the onboarding agent.
import type { SectionType } from './types';

export const sectionCatalog = {
  hero: {
    label: 'Hero',
    description:
      'Introduce the offer and its primary action. Immersive uses a full photo; collage adds one or two images. Both need supplied image/product media.',
    variants: ['split', 'centered', 'cover', 'immersive', 'collage'],
  },
  features: {
    label: 'Benefits',
    description:
      'Explain features, services or differentiators. Bento uses varied card sizes; tabs need media on every item.',
    variants: ['grid', 'split', 'list', 'bento', 'tabs'],
  },
  gallery: {
    label: 'Showcase',
    description:
      'Show products, projects or offers. Catalog adds prices/actions; menu groups by category and can omit imagery.',
    variants: ['cards', 'editorial', 'catalog', 'menu'],
  },
  steps: {
    label: 'How it works',
    description:
      'Explain a sequence: timeline or cards in columns; vertical beside an introduction; image-accordion with section.media; alternating with media on every item.',
    variants: ['timeline', 'cards', 'vertical', 'image-accordion', 'alternating'],
  },
  pricing: {
    label: 'Pricing',
    description: 'Compare plans, packages or offers.',
    variants: ['cards', 'compact'],
  },
  testimonial: {
    label: 'Testimonial',
    description:
      'Show supplied, attributable quotes. Spotlight/split use quote/author/role; wall/carousel use items with optional portraits.',
    variants: ['spotlight', 'split', 'wall', 'carousel'],
  },
  logos: {
    label: 'References',
    description:
      'Display supplied client or partner names/logos in a compact band or grid. Never invent endorsements.',
    variants: ['band', 'grid'],
  },
  stats: {
    label: 'Key figures',
    description:
      'Highlight supplied figures inline or beside media. Visual requires section.media; omit unverified claims.',
    variants: ['inline', 'visual'],
  },
  team: {
    label: 'People',
    description:
      'Introduce one founder with a personal letter, or a team grid. Founder displays the first person; grid displays everyone.',
    variants: ['founder', 'grid'],
  },
  contact: {
    label: 'Contact & location',
    description:
      'Show address, email, phone, hours or a working contact action. Map needs a supplied map image and HTTPS directions URL.',
    variants: ['details', 'map'],
  },
  comparison: {
    label: 'Comparison',
    description:
      'Compare criteria in a table (one value per column) or supplied labeled before/after images.',
    variants: ['table', 'before-after'],
  },
  agenda: {
    label: 'Programme',
    description:
      'Present scheduled sessions with times, or learning modules with durations. Actions link to working flows.',
    variants: ['schedule', 'curriculum'],
  },
  faq: {
    label: 'FAQ',
    description: 'Answer common questions.',
    variants: ['accordion', 'columns'],
  },
  cta: {
    label: 'Call to action',
    description: 'Invite the visitor to take the next step.',
    variants: ['banner', 'centered'],
  },
} as const satisfies Record<
  SectionType,
  { label: string; description: string; variants: readonly string[] }
>;
