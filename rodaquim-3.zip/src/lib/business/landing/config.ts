// @polsia:user-owned — onboarding edits this composition. See docs/landing.md.
import { siteName } from '@/lib/brand';
import type { LandingConfig } from './types';

export const landingConfig: LandingConfig = {
  id: 'home',
  theme: {
    palette: 'forest',
    typography: 'sans',
    radius: 'sharp',
    colors: {
      primary: '#b45309',
      accent: '#f3eadb',
      background: '#fbf8f2',
      text: '#2d261e',
    },
  },
  brand: {
    name: siteName,
    monogram: 'R',
    tagline: 'A base confiável para cuidar, equipar e entender sua Bajaj.',
  },
  navigation: [
    { label: 'A base', sectionId: 'base' },
    { label: 'Como consultar', sectionId: 'como-funciona' },
    { label: 'Ponto de partida', sectionId: 'n150' },
  ],
  primaryAction: { label: 'Conhecer a base', href: '#base' },
  footer: {
    description:
      'Um portal independente para transformar informação espalhada sobre Bajaj em decisões mais claras.',
    links: [
      { label: 'A base', href: '#base' },
      { label: 'Falar com o projeto', href: 'mailto:rodaquim-3@polsia.app' },
    ],
    copyright: `© ${siteName}. Projeto independente, sem vínculo oficial com a Bajaj do Brasil.`,
  },
  sections: [
    {
      id: 'hero',
      enabled: true,
      type: 'hero',
      variant: 'split',
      eyebrow: 'Rodaquim · Bajaj BR · Projeto independente',
      title: 'Antes de comprar, fazer ou adaptar,\nconsulte a base.',
      description:
        'A base confiável para cuidar, equipar e entender sua Bajaj — começando pela Pulsar N150.',
      primaryAction: { label: 'Conhecer a base', href: '#base' },
      secondaryAction: { label: 'Falar com o projeto', href: 'mailto:rodaquim-3@polsia.app' },
      note: 'Fontes, data de verificação e nível de confiança em cada informação importante.',
      media: {
        kind: 'product',
        src: '/landing/rodaquim-technical.svg',
        alt: 'Diagrama técnico abstrato representando uma motocicleta em uma ficha de referência.',
        caption: 'Ficha de modelo / 001 · Pulsar N150',
      },
    },
    {
      id: 'base',
      enabled: true,
      type: 'features',
      variant: 'bento',
      heading: 'Uma base para a pergunta que realmente importa: isso serve na minha moto?',
      description:
        'Catálogo, compatibilidade, manutenção e comunidade reunidos com contexto — sem apresentar alegação como fato.',
      items: [
        {
          title: 'Catálogo de peças',
          description:
            'Códigos OEM, alternativas, medidas, fabricantes, lojas e preço com data de verificação.',
          icon: 'layers',
        },
        {
          title: 'Compatibilidade sem chute',
          description:
            'Confirmada, testada, provável, com adaptação, não confirmada ou incompatível.',
          icon: 'shield',
        },
        {
          title: 'Manutenção que orienta',
          description:
            'Guias e checklists para óleo, filtros, corrente, pneus, bateria e revisões.',
          icon: 'clock',
        },
        {
          title: 'Relatos com contexto',
          description:
            'Experiências de proprietários e comunidade claramente separadas de fontes oficiais e técnicas.',
          icon: 'heart',
        },
      ],
    },
    {
      id: 'confiabilidade',
      enabled: true,
      type: 'comparison',
      variant: 'table',
      heading: 'Nem toda informação tem o mesmo peso.',
      description:
        'O Rodaquim deixa visível a diferença entre uma referência técnica, uma experiência e uma publicidade.',
      columns: [
        { label: 'O que aparece', highlighted: true },
        { label: 'Como o Rodaquim trata' },
        { label: 'O que você pode decidir' },
      ],
      rows: [
        {
          label: 'Fonte oficial ou técnica',
          values: ['Documento, manual ou especificação', 'Referência principal', 'Usar como base'],
        },
        {
          label: 'Experiência da comunidade',
          values: [
            'Relato ou teste de proprietário',
            'Evidência contextual',
            'Investigar e comparar',
          ],
        },
        {
          label: 'Alegação ou publicidade',
          values: [
            'Sem evidência suficiente',
            'Identificada como tal',
            'Não tratar como confirmação',
          ],
        },
      ],
    },
    {
      id: 'como-funciona',
      enabled: true,
      type: 'steps',
      variant: 'timeline',
      heading: 'Da dúvida à escolha, com os sinais à vista.',
      items: [
        {
          title: 'Encontre',
          description: 'Busque por peça, código, acessório, problema, marca, tutorial ou produto.',
        },
        {
          title: 'Compare',
          description:
            'Leia compatibilidade, fonte, data, preço, loja, especificação e relatos lado a lado.',
        },
        {
          title: 'Decida',
          description:
            'Entenda o que está confirmado, o que é provável e o que exige adaptação ou cuidado.',
        },
      ],
    },
    {
      id: 'n150',
      enabled: true,
      type: 'faq',
      variant: 'accordion',
      heading: 'Começamos pela Pulsar N150.',
      items: [
        {
          question: 'O Rodaquim é um site oficial da Bajaj?',
          answer:
            'Não. O Rodaquim é um projeto independente, sem vínculo oficial com a Bajaj do Brasil.',
        },
        {
          question: 'Por que começar pela N150?',
          answer:
            'A N150 é o primeiro foco do portal. A estrutura foi pensada para crescer depois para outros modelos, anos, versões e mercados.',
        },
        {
          question: 'Uma peça marcada como provável está garantida?',
          answer:
            'Não. “Provável” indica que há sinais de compatibilidade, mas ainda faltam evidências suficientes para uma confirmação.',
        },
        {
          question: 'Posso sugerir uma correção ou um relato?',
          answer:
            'Sim. O projeto foi pensado para receber sugestões, fontes e experiências que ajudem a melhorar a base.',
        },
      ],
    },
    {
      id: 'sobre',
      enabled: true,
      type: 'cta',
      variant: 'banner',
      heading: 'Uma base aberta a correções, feita para quem quer pilotar melhor informado.',
      description: 'Quer contribuir com uma fonte, um teste ou uma correção? Fale com o projeto.',
      action: { label: 'Enviar uma sugestão', href: 'mailto:rodaquim-3@polsia.app' },
      secondaryAction: { label: 'Voltar ao início', href: '#hero' },
    },
  ],
};
