// @polsia:user-owned — presets and optional brand colors share one rendering contract.
import type { CSSProperties } from 'react';
import type { LandingColors, LandingTheme, Palette } from './types';

const palettes: Record<Palette, LandingColors & { muted: string; line: string }> = {
  cobalt: {
    primary: '#2949eb',
    accent: '#edf1ff',
    background: '#ffffff',
    text: '#17213d',
    muted: '#626b80',
    line: '#e3e7f0',
  },
  forest: {
    primary: '#245647',
    accent: '#e9eee8',
    background: '#f6f5f1',
    text: '#202c25',
    muted: '#62695e',
    line: '#d9ded3',
  },
  wine: {
    primary: '#642c38',
    accent: '#f7e6c5',
    background: '#fff9ed',
    text: '#40242b',
    muted: '#7b6360',
    line: '#e7d9c4',
  },
};

export function resolveLandingColors(theme: LandingTheme): LandingColors {
  const preset = palettes[theme.palette];
  return {
    primary: theme.colors?.primary ?? preset.primary,
    accent: theme.colors?.accent ?? preset.accent,
    background: theme.colors?.background ?? preset.background,
    text: theme.colors?.text ?? preset.text,
  };
}

function luminance(hex: string): number {
  const value =
    hex.length === 4 ? [...hex.slice(1)].map((digit) => digit + digit).join('') : hex.slice(1);
  const linear = (offset: number) => {
    const channel = Number.parseInt(value.slice(offset, offset + 2), 16) / 255;
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * linear(0) + 0.7152 * linear(2) + 0.0722 * linear(4);
}

function readableForeground(background: string, preferred: string): string {
  const bg = luminance(background);
  const fg = luminance(preferred);
  if ((Math.max(bg, fg) + 0.05) / (Math.min(bg, fg) + 0.05) >= 4.5) return preferred;
  return (bg + 0.05) / 0.05 > 1.05 / (bg + 0.05) ? '#000000' : '#ffffff';
}

export function landingThemeStyle(
  theme: LandingTheme,
): CSSProperties & Record<`--land-${string}`, string> {
  const colors = resolveLandingColors(theme);
  const preset = palettes[theme.palette];
  const customSurface = theme.colors?.background !== undefined || theme.colors?.text !== undefined;
  return {
    '--land-accent': colors.primary,
    '--land-tint': colors.accent,
    '--land-bg': colors.background,
    '--land-ink': colors.text,
    '--land-muted': customSurface
      ? `color-mix(in srgb, ${colors.text} 70%, ${colors.background})`
      : preset.muted,
    '--land-line': customSurface
      ? `color-mix(in srgb, ${colors.text} 18%, ${colors.background})`
      : preset.line,
    '--land-on-accent': readableForeground(colors.primary, colors.background),
    '--land-accent-ink': readableForeground(colors.background, colors.primary),
  };
}
