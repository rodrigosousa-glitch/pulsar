// @polsia:user-owned — serializable contract between an agent and the landing renderer.

export type Palette = 'cobalt' | 'forest' | 'wine';
export type Typography = 'sans' | 'editorial' | 'rounded';
export type Radius = 'sharp' | 'soft' | 'round';
export type Action = { label: string; href: string };
export type LandingColors = { primary: string; accent: string; background: string; text: string };
export type LandingTheme = {
  palette: Palette;
  typography: Typography;
  radius: Radius;
  colors?: Partial<LandingColors>;
};
export type SectionBase = { id: string; enabled: boolean };
export type LandingMedia = { src: string; alt: string; caption?: string };
export type HeroSection = SectionBase & {
  type: 'hero';
  variant: 'split' | 'centered' | 'cover' | 'immersive' | 'collage';
  eyebrow?: string;
  title: string;
  description: string;
  primaryAction: Action;
  secondaryAction?: Action;
  note?: string;
  media: { kind: 'image' | 'dashboard' | 'product'; src?: string; alt: string; caption?: string };
  /** One or two additional images for the collage variant. */
  collage?: LandingMedia[];
};
export type FeatureIcon =
  | 'layers'
  | 'sparkles'
  | 'clock'
  | 'shield'
  | 'leaf'
  | 'heart'
  | 'arrow'
  | 'globe';
export type FeaturesSection = SectionBase & {
  type: 'features';
  variant: 'grid' | 'split' | 'list' | 'bento' | 'tabs';
  heading: string;
  description?: string;
  items: { title: string; description: string; icon: FeatureIcon; media?: LandingMedia }[];
};
export type GallerySection = SectionBase & {
  type: 'gallery';
  variant: 'cards' | 'editorial' | 'catalog' | 'menu';
  heading: string;
  description?: string;
  items: {
    title: string;
    subtitle?: string;
    image?: string;
    alt?: string;
    tag?: string;
    action?: Action;
    price?: string;
    category?: string;
  }[];
};
export type StepsSection = SectionBase & {
  type: 'steps';
  variant: 'timeline' | 'cards' | 'vertical' | 'image-accordion' | 'alternating';
  heading: string;
  description?: string;
  /** Required for image-accordion. */
  media?: { src: string; alt: string };
  items: {
    title: string;
    description: string;
    /** Required on every item for alternating. */
    media?: { src: string; alt: string };
  }[];
};
export type PricingSection = SectionBase & {
  type: 'pricing';
  variant: 'cards' | 'compact';
  heading: string;
  description?: string;
  plans: {
    name: string;
    description: string;
    price: string;
    period?: string;
    features: string[];
    action: Action;
    featured?: boolean;
  }[];
};
export type TestimonialSection = SectionBase & {
  type: 'testimonial';
  variant: 'spotlight' | 'split' | 'wall' | 'carousel';
  quote?: string;
  author?: string;
  role?: string;
  heading?: string;
  description?: string;
  items?: { quote: string; author: string; role?: string; portrait?: LandingMedia }[];
};
export type LogosSection = SectionBase & {
  type: 'logos';
  variant: 'band' | 'grid';
  heading: string;
  description?: string;
  items: { name: string; image?: string; href?: string }[];
};
export type StatsSection = SectionBase & {
  type: 'stats';
  variant: 'inline' | 'visual';
  heading: string;
  description?: string;
  items: { value: string; label: string; description?: string }[];
  media?: LandingMedia;
};
export type TeamSection = SectionBase & {
  type: 'team';
  variant: 'founder' | 'grid';
  heading: string;
  description?: string;
  people: { name: string; role: string; bio?: string; portrait?: LandingMedia; action?: Action }[];
};
export type ContactSection = SectionBase & {
  type: 'contact';
  variant: 'details' | 'map';
  heading: string;
  description?: string;
  address?: string;
  email?: string;
  phone?: string;
  hours?: { label: string; value: string }[];
  action?: Action;
  /** A supplied map image and a real directions link; no API key or invented map. */
  map?: LandingMedia & { href: string };
};
export type ComparisonSection = SectionBase & {
  type: 'comparison';
  variant: 'table' | 'before-after';
  heading: string;
  description?: string;
  columns?: { label: string; highlighted?: boolean }[];
  rows?: { label: string; values: string[] }[];
  before?: LandingMedia & { label: string };
  after?: LandingMedia & { label: string };
};
export type AgendaSection = SectionBase & {
  type: 'agenda';
  variant: 'schedule' | 'curriculum';
  heading: string;
  description?: string;
  items: {
    title: string;
    description?: string;
    label?: string;
    time?: string;
    duration?: string;
    action?: Action;
  }[];
};
export type FaqSection = SectionBase & {
  type: 'faq';
  variant: 'accordion' | 'columns';
  heading: string;
  items: { question: string; answer: string }[];
};
export type CtaSection = SectionBase & {
  type: 'cta';
  variant: 'banner' | 'centered';
  heading: string;
  description?: string;
  action: Action;
  secondaryAction?: Action;
};
export type LandingSection =
  | HeroSection
  | FeaturesSection
  | GallerySection
  | StepsSection
  | PricingSection
  | TestimonialSection
  | LogosSection
  | StatsSection
  | TeamSection
  | ContactSection
  | ComparisonSection
  | AgendaSection
  | FaqSection
  | CtaSection;
export type SectionType = LandingSection['type'];
export type LandingConfig = {
  id: string;
  theme: LandingTheme;
  brand: { name: string; monogram: string; tagline: string };
  navigation: { label: string; sectionId: string }[];
  primaryAction: Action;
  footer: { description: string; links: Action[]; copyright: string };
  sections: LandingSection[];
};
