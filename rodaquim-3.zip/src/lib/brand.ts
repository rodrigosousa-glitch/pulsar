// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'Rodaquim';
export const siteDescription = 'A base confiável para cuidar, equipar e entender sua Bajaj.';

// PWA + social-share colors. HEX only (the oklch() tokens in globals.css aren't
// readable here) — set to match your brand seed.
export const brandVisual = {
  /** PWA browser-UI / status-bar color. */
  themeColor: '#b45309',
  /** PWA splash + install background. */
  backgroundColor: '#f8f4ec',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#f8f4ec',
    foreground: '#2d261e',
    /** Second line under the site name; '' hides it. */
    tagline: 'A base confiável para cuidar, equipar e entender sua Bajaj.',
  },
} as const;
