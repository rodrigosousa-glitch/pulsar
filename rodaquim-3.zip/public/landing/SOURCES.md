# Landing assets

DM Sans and Fraunces are distributed under the SIL Open Font License. License files are included alongside the fonts.

- `dm-sans-latin.woff2`: https://fonts.gstatic.com/s/dmsans/v17/rP2Yp2ywxg089UriI5-g4vlH9VoD8Cmcqbu0-K6z9mXg.woff2
- `fraunces-latin.woff2`: https://fonts.gstatic.com/s/fraunces/v38/6NUu8FyLNQOQZAnv9bYEvDiIdE9Ea92uemAk_WBq8U_9v0c2Wa0K7iN7hzFUPJH58nib14c7qv8oRcTn.woff2
- `placeholder.svg`: original neutral image placeholder. Replace it with the business's imagery during onboarding.
