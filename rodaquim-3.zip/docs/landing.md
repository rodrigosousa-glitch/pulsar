# Configure the landing

`/` renders a complete landing from `src/lib/business/landing/config.ts`.
The template includes the sections and their responsive styles; no editor or
studio is shipped. The starter uses neutral copy and an image placeholder that
onboarding replaces with the business's content.

## Onboarding workflow

1. Read the business brief and roadmap. Set the identity in `src/lib/brand.ts`.
2. Read `src/lib/business/landing/catalog.ts` for available pieces,
   `types.ts` for their fields and `schema.ts` for variant requirements. Inspect
   the active home and current `config.ts`; preserve an existing composition
   outside the requested changes. Use the decisions below before editing.
3. Set `theme`: palette (`cobalt`, `forest`, `wine`), typography (`sans`,
   `editorial`, `rounded`) and radius (`sharp`, `soft`, `round`). Optionally set
   `theme.colors` to match the business's brand; palettes are starting points,
   not a restriction on which colors the landing can use.
4. Keep section IDs unique. Array order determines page order; `enabled: false`
   hides a section. Update navigation and action anchors to target visible
   sections. `#landing-footer` targets the footer.
5. Replace placeholder images with business assets in `public/` or HTTPS image
   URLs. Supply descriptive alt text. Use supported facts and attributable
   testimonials. Preserve supplied prices; when pricing decisions are delegated,
   record the chosen launch price and rationale without presenting it as market
   research or founder approval. Omit optional sections without supporting content.
6. Point actions at working routes, section anchors, HTTPS destinations or
   `mailto:` addresses. Install the appropriate module for capabilities such
   as checkout or auth, then link its real flow. A CTA is a normal link, with
   no simulated success or demo dialog.
7. Use the workflow's verification helper when one is supplied; it owns the
   required commands. Otherwise run `npm test`, `npm run lint`,
   `SKIP_ENV_VALIDATION=1 npm run build`, then `npm run typecheck`.
   Complete the page and action checks below; a build alone does not prove them.

## Composition decisions

Before changing configuration, record a short composition rationale in the
workflow's existing analysis/plan or working notes. No extra planning file is
required. In read-only phases, record decisions without editing the app.

1. **Purpose:** identify the visitor, concrete offer and one primary conversion
   goal from the brief and roadmap. Separate capabilities available now from
   planned capabilities. Explicit customer requirements take precedence over
   the starter composition.
2. **Content:** inventory supplied copy, assets, prices, people, references and
   customer quotes. Each proposed section needs useful supported content and a
   visitor question to answer. Omit optional sections without it; report missing
   content for an explicit requirement instead of silently dropping that requirement.
3. **Structure:** choose the smallest composition that covers those questions.
   Introduce the offer, explain it, provide available evidence and lead to the
   action. These are roles, not mandatory sections. Preserve a clear first screen,
   one hero/H1 and a small navigation. The catalog is not a checklist to display.
4. **Variants:** match the amount and shape of content to a layout. Use `menu`
   for categorized text/prices, `catalog` for image-led offers, `schedule` for
   timed sessions, and `curriculum` for ordered learning modules. Choose an
   immersive/collage hero only with appropriate imagery; choose tabs only when
   each item has useful media. One quote suits `spotlight`/`split`; multiple quotes
   can use `wall`/`carousel`. Keep essential decision content outside hidden tabs
   or later slides. Use the variant reference below for exact fields.
5. **Coherence:** choose one theme for the page, using the supplied brand colors
   when available. Vary layout where the content benefits from it; avoid changing
   variants at random or repeating the same card composition in every section.
   Keep configured defaults when they fit. All pieces are available to every business.
6. **Actions:** name each CTA's promised outcome and actual destination. A contact
   email or informational anchor can be the correct primary action. A signup,
   checkout or booking CTA needs its corresponding working flow; scrolling to
   explanatory text does not complete that action. During a landing-only bake,
   use an honest contact/exploration action or a supplied, verified HTTPS flow
   that already delivers the promised action, within that workflow's scope.

For each selected section, the rationale should identify its role, `type` and
`variant`, supplied content/assets and any action destination. Resolve exact
variant names and requirements from this checkout, not a remembered template
version. Keep implementation details in engineering notes, not visitor-facing copy.

### Missing imagery

Use existing assets or exact URLs returned by the workflow's asset tools. Create
and verify a local file before referencing a new path. With no suitable photograph,
choose a layout that needs less imagery and, when necessary, create a simple
decorative SVG in `public/` with honest alt text. A decorative illustration can
support a hero; it cannot stand in for a real person's portrait, a customer logo,
a location map or evidence of a before/after result. Omit optional proof sections
or report the missing required asset. The hero's `dashboard` media is a static
illustration with sample data, so use it only when appropriate to the offer and
clearly describe it as illustrative; it is not proof of a working integration.

### Completion checks

- The configuration passes `landingConfigSchema` and the workflow's build checks.
  Keep the home page's validation and server-rendered metadata intact.
- Every visible section supports the brief and contains business content rather
  than starter copy. Factual claims, identities and endorsements have support;
  launch prices follow supplied terms or recorded, authorized product decisions.
  Future roadmap features are presented as planned, when relevant.
- Inspect `/` at desktop and narrow mobile widths. Check image loading, text
  contrast, wrapping and overflow, including custom colors and the chosen variants.
- Follow every navigation link and CTA. Anchors resolve to enabled sections or
  `#landing-footer`; routes exist and the promised flow works. Schema validation
  checks shapes and URL syntax, not destination existence or business truth.
- Check keyboard navigation for the interactive variants you used, reduced motion
  and readable content before JavaScript. Preserve the existing Motion behavior.
- Report the chosen composition, working destinations, verification performed and
  any unmet requirement.

## Variant reference

| Section | Variants |
| --- | --- |
| Hero | `split`, `centered`, `cover`, `immersive`, `collage` |
| Benefits / services | `grid`, `split`, `list`, `bento`, `tabs` |
| Products / projects / menu | `cards`, `editorial`, `catalog`, `menu` |
| How it works | `timeline`, `cards`, `vertical`, `image-accordion`, `alternating` |
| Pricing | `cards`, `compact` |
| Testimonial | `spotlight`, `split`, `wall`, `carousel` |
| References (`logos`) | `band`, `grid` |
| Key figures (`stats`) | `inline`, `visual` |
| People (`team`) | `founder`, `grid` |
| Contact / location | `details`, `map` |
| Comparison | `table`, `before-after` |
| Programme (`agenda`) | `schedule`, `curriculum` |
| FAQ | `accordion`, `columns` |
| Call to action | `banner`, `centered` |

Hero media supports `image`, `product` (both require `src`), or `dashboard`
(a static software illustration). Choose imagery suited to the business.
Sections are independent of business categories: compose them from the brief.

### Choose content and layouts

The catalog contains 14 section types and 41 layouts. The same pieces can serve
software, commerce, services, hospitality, education or other businesses; there
is no business-type restriction. Select a layout based on the available content.

- **Hero:** `immersive` places copy over a supplied image; `collage` arranges the
  primary image beside one or two additional images in `collage`. Both require
  `media.kind: 'image' | 'product'` and `media.src`.
- **Benefits:** `bento` varies card sizes and accepts optional item `media`;
  `tabs` switches the description and image and requires `media` on every item.
- **Offers:** `catalog` uses image cards with optional `price` and `action`;
  `menu` groups items by optional `category`, with optional images. Other gallery
  layouts require `image` and `alt` on every item. Prices are supplied strings,
  not computed checkout amounts.
- **References:** `logos.items` accepts `{ name, image?, href? }`. Use supplied
  client or partner references only; names can render without logo assets.
- **Figures:** `stats.items` accepts `{ value, label, description? }`.
  `visual` requires section `media`. Values are supplied facts, never invented
  counters or estimates.
- **People:** `team.people` accepts `{ name, role, bio?, portrait?, action? }`.
  `founder` introduces the first person; `grid` displays everyone in the list. Portraits
  are optional and must depict the people being introduced.
- **Testimonials:** existing `spotlight`/`split` use `quote`, `author`, `role`.
  `wall`/`carousel` use `items: [{ quote, author, role?, portrait? }]` with optional
  section `heading` and `description`. The carousel is manual, without autoplay.
- **Contact:** supply `address`, `email`, `phone`, `hours: [{ label, value }]`
  and/or `action`. `map` also requires `map: { src, alt, href }`: a supplied map
  image and HTTPS directions URL. It does not load a map service or create a
  contact form. Email and phone fields become working contact links.
- **Comparison:** `table` needs `columns: [{ label, highlighted? }]` and
  `rows: [{ label, values: string[] }]`, with exactly one value per column.
  `before-after` needs `before` and `after`, each `{ src, alt, label }`, showing
  comparable supplied views. The visitor controls the reveal with a slider.
- **Programme:** `agenda.items` accepts `{ title, description?, label?, time?,
  duration?, action? }`. `schedule` emphasizes sessions and times; `curriculum`
  presents ordered learning modules. Booking and enrollment actions must link
  to real flows.

Shared `media` and `portrait` fields use `{ src, alt, caption? }` with a local
public path or HTTPS URL. Configuration validation rejects missing imagery
required by a layout, unattributed quotes and inconsistent table rows. Omit
sections whose content is unavailable; do not fabricate proof to fill a layout.
The neutral starter remains a small composition, rather than enabling every
section by default.

Tabs, testimonial navigation and the comparison slider support keyboard input.
Before JavaScript loads, text remains readable; tabs and carousel expose all
items, and image comparison starts at an even split with its slider disabled
until hydration. These interactions follow the same reduced-motion preference
as the surrounding landing.

### Customize the colors

Set any of these four fields in `config.ts`; omitted fields inherit the selected
palette. Use opaque hexadecimal colors (`#RGB` or `#RRGGBB`). Other CSS syntax,
including color names, alpha channels and CSS variables, is rejected.

```ts
theme: {
  palette: 'forest',
  typography: 'editorial',
  radius: 'soft',
  colors: {
    primary: '#b34527',    // Buttons, brand mark and emphasis
    accent: '#f6e5d8',     // Tinted cards and secondary surfaces
    background: '#fffaf4', // Page background
    text: '#30221c',       // Headings and body text
  },
},
```

The renderer applies these colors to every section without changing its CSS.
Muted text and borders follow custom page/text colors. Text on primary buttons
and banners automatically uses a contrasting foreground; primary-colored text
also gets a readable fallback on the page background. Check your chosen text
against both the page and accent backgrounds on desktop and mobile. Custom
colors are not a guarantee of contrast for every arbitrary combination.

Remove `theme.colors` to restore the palette. Existing configurations require
no migration. These colors apply to the landing; other app pages still use
the shared `brand_tokens` theme.

### Choose a steps layout

All five layouts use the same `heading`, optional `description`, and ordered
`items` with `title` and `description`. Choose by the content and desired
composition, independently of business category:

| Variant | Composition | Required imagery |
| --- | --- | --- |
| `timeline` | Numbered columns with connecting rules; vertical on mobile | None |
| `cards` | Tinted cards with large numbers; stacked on mobile | None |
| `vertical` | Introduction on the left, a vertical timeline on the right | None |
| `image-accordion` | One image on the left, expandable steps on the right | Section-level `media` |
| `alternating` | Full-width rows alternating image/text sides; image first on mobile | `media` on every item |

Each `media` is `{ src: '/images/process.jpg', alt: 'Describe the actual image' }`.
Add the referenced business image to `public/images/` or use an HTTPS URL. For
`image-accordion`, set `section.media`; for `alternating`, set
`section.items[n].media` for every step. The schema rejects missing images,
unsupported sources and empty alt text. If the business has no appropriate
imagery, choose a text-only layout. Existing `timeline` and `cards`
configurations need no changes.

The accordion opens its first step by default and allows one open step at a
time. It supports keyboard interaction and works without JavaScript. Each
section has its own disclosure group. All layouts inherit the palette, fonts,
corners and section entrance animation from the landing.

Motion is installed and integrated into every section variant. Sections enter
once when scrolled into view, action links respond to hover and press, and the
mobile menu has a short entrance. These defaults live in
`src/components/custom/landing/landing-page.tsx` and `landing-action.tsx` in the
same directory; onboarding configures the landing and keeps these behaviors.
Do not install or wire another animation
library. The renderer uses `LazyMotion` with `domAnimation`, honors the device's
reduced-motion preference, and keeps server-rendered content visible before
JavaScript loads or when it is disabled. When extending the renderer, preserve
these defaults and check desktop, mobile and reduced motion.

`src/app/(setup)/page.tsx` validates the configuration before rendering and
reads page metadata from `brand.ts`. The landing owns its header and footer;
other public pages use `src/lib/nav.ts` and `SiteNav`/`SiteFooter`. Add links
from the landing to any additional public pages and installed features. If you
replace the landing with a different home page, remove the `/` suppression in
both components in `src/components/custom/site-nav.tsx` or supply your own
navigation there.

Custom app behavior still belongs in user-owned code. Extend the section
renderer only when the supplied catalog cannot represent a required section.
